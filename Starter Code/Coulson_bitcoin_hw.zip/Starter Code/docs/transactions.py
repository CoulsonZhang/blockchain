Q1_txid  = '243ba5dd66f1d7e4676f5c3eebd340c82b25f60c228b29dd3facab1dad9e509b'
Q2a_txid = '803547d641735f52ee16f677209fb800d8423cdb339342bf49bb3356cc915e4c'
Q2b_txid = 'b60d43ea231c62c75341afd1f27bf404ead61bd5800294e8239dd8550881a31d'
Q3a_txid = '17165ccf8e122d1aea1c18e39034d45d90395d79a0d39e56bd6e5f495dad8616'
Q3b_txid = '29f9c4c97e2c9f319de3e444721d4a7b23b4136bfd066dcdb3f6485a28b8a148'

# Q4.py is finished and execution result of swap.py shows below:
# If Alice redeems the money:
# (swin) coulson@CoulsonStudio Starter Code % python swap.py
# Alice swap tx (BTC) created successfully!
# Bob swap tx (BCY) created successfully!
# Alice redeem from swap tx (BCY) created successfully!
# Bob redeem from swap tx (BTC) created successfully!

# If Alice doesn't redeem the money:
# (swin) coulson@CoulsonStudio Starter Code % python swap.py
# Alice swap tx (BTC) created successfully!
# Bob swap tx (BCY) created successfully!
# Bob return coins (BCY) tx created successfully!
# Alice return coins tx (BTC) created successfully!